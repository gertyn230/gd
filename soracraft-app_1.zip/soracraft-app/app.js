require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');

const { attachUser, attachFlash } = require('./middleware/auth');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// contentSecurityPolicy вимкнено для простоти демо (щоб працювали Google Fonts з CDN).
// У продакшені налаштуй CSP явно замість вимкнення.
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(
  session({
    name: 'soracraft.sid',
    secret: process.env.SESSION_SECRET || 'soracraft-dev-secret-change-me',
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 1000 * 60 * 60 * 24 * 7, // 7 днів
      httpOnly: true,
      sameSite: 'lax'
    }
  })
);

app.use(attachUser);
app.use(attachFlash);

app.use('/', require('./routes/pages'));
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/cabinet'));
app.use('/', require('./routes/shop'));
app.use('/', require('./routes/admin'));

// Створює перший акаунт адміністратора при первому запуску, якщо жодного ще немає.
// Дані для входу виводяться в консоль лише один раз — одразу зміни пароль після входу.
function ensureAdminSeed() {
  const usersModel = require('./models/users');
  const users = usersModel.all();
  const hasAdmin = users.some((u) => u.role === 'admin');
  if (!hasAdmin) {
    usersModel.create({
      nick: 'Admin',
      email: 'admin@soracraft.net',
      password: 'admin12345',
      role: 'admin'
    });
    console.log('----------------------------------------------------');
    console.log('Створено акаунт адміністратора за замовчуванням:');
    console.log('  Пошта:  admin@soracraft.net');
    console.log('  Пароль: admin12345');
    console.log('Увійди й одразу зміни пароль у кабінеті («Безпека»).');
    console.log('----------------------------------------------------');
  }
}
ensureAdminSeed();

app.use((req, res) => {
  res.status(404).render('404', { title: 'Сторінку не знайдено — SORACRAFT', activeNav: '' });
});

module.exports = app;
