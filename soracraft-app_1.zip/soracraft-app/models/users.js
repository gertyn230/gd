const bcrypt = require('bcryptjs');
const db = require('../db');

const NICK_RE = /^[a-zA-Z0-9_]{3,16}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function findByNick(nick) {
  return db.get('users').find({ nickLower: nick.toLowerCase() }).value();
}

function findByEmail(email) {
  return db.get('users').find({ emailLower: email.toLowerCase() }).value();
}

function findByLogin(login) {
  return findByNick(login) || findByEmail(login);
}

function findById(id) {
  return db.get('users').find({ id }).value();
}

function create({ nick, email, password, role }) {
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const passHash = bcrypt.hashSync(password, 10);
  const user = {
    id,
    nick,
    nickLower: nick.toLowerCase(),
    email,
    emailLower: email.toLowerCase(),
    passHash,
    coins: 1240,
    rank: 'Новачок',
    role: role || 'user', // 'user' | 'moderator' | 'admin'
    banned: false,
    hoursPlayed: 0,
    emailVerified: false,
    joined: new Date().toISOString(),
    loginHistory: [{ at: new Date().toISOString(), ip: null }]
  };
  db.get('users').push(user).write();
  return user;
}

function verifyPassword(user, password) {
  return bcrypt.compareSync(password, user.passHash);
}

function all() {
  return db.get('users').value();
}

function setRole(userId, role) {
  db.get('users').find({ id: userId }).assign({ role }).write();
  return findById(userId);
}

function setBanned(userId, banned) {
  db.get('users').find({ id: userId }).assign({ banned }).write();
  return findById(userId);
}

function updatePassword(userId, newPassword) {
  const passHash = bcrypt.hashSync(newPassword, 10);
  db.get('users').find({ id: userId }).assign({ passHash }).write();
  return findById(userId);
}

function remove(userId) {
  db.get('users').remove({ id: userId }).write();
}

function recordLogin(userId, ip) {
  db.get('users')
    .find({ id: userId })
    .get('loginHistory')
    .push({ at: new Date().toISOString(), ip: ip || null })
    .write();
}

function addCoins(userId, amount) {
  const user = db.get('users').find({ id: userId });
  const current = user.value().coins || 0;
  user.assign({ coins: current + amount }).write();
  return user.value();
}

function setRank(userId, rank) {
  db.get('users').find({ id: userId }).assign({ rank }).write();
  return findById(userId);
}

module.exports = {
  NICK_RE,
  EMAIL_RE,
  findByNick,
  findByEmail,
  findByLogin,
  findById,
  create,
  verifyPassword,
  recordLogin,
  addCoins,
  setRank,
  all,
  setRole,
  setBanned,
  updatePassword,
  remove
};
