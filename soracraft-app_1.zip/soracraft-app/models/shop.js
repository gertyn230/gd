const db = require('../db');

function all() {
  return db.get('shopPackages').value();
}

function findById(id) {
  return db.get('shopPackages').find({ id }).value();
}

module.exports = { all, findById };
