const db = require('../db');

function all() {
  // найновіші спочатку
  return [...db.get('news').value()].sort((a, b) => new Date(b.date) - new Date(a.date));
}

function findBySlug(slug) {
  return db.get('news').find({ slug }).value();
}

module.exports = { all, findBySlug };
