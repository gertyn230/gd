const db = require('../db');

function all() {
  return db.get('worlds').value();
}

function findBySlug(slug) {
  return db.get('worlds').find({ slug }).value();
}

module.exports = { all, findBySlug };
