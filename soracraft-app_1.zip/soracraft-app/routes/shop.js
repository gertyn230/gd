const express = require('express');
const router = express.Router();
const shopModel = require('../models/shop');
const usersModel = require('../models/users');
const { requireAuth } = require('../middleware/auth');

router.get('/shop', (req, res) => {
  res.render('shop', {
    title: 'Магазин — SORACRAFT',
    activeNav: 'shop',
    packages: shopModel.all()
  });
});

// ДЕМО: реальна оплата тут не виконується. У продакшені цей маршрут
// має викликати платіжний шлюз (Stripe/LiqPay/WayForPay тощо) і нараховувати
// монети лише після підтвердження вебхуком від платіжної системи.
router.post('/shop/buy/:id', requireAuth, (req, res) => {
  const pkg = shopModel.findById(req.params.id);
  if (!pkg) {
    req.session.flash = { type: 'bad', message: 'Такого товару не існує' };
    return res.redirect('/shop');
  }

  if (pkg.type === 'coins') {
    usersModel.addCoins(req.session.userId, pkg.amount);
    req.session.flash = { type: 'ok', message: `Демо-покупка: нараховано ${pkg.amount} монет` };
  } else if (pkg.type === 'rank') {
    const rankName = pkg.name.replace('Ранг ', '');
    usersModel.setRank(req.session.userId, rankName);
    req.session.flash = { type: 'ok', message: `Демо-покупка: ранг "${rankName}" активовано` };
  }

  res.redirect('/cabinet');
});

module.exports = router;
