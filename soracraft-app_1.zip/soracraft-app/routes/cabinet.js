const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const usersModel = require('../models/users');

router.get('/cabinet', requireAuth, (req, res) => {
  const user = usersModel.findById(req.session.userId);
  const history = [...(user.loginHistory || [])].reverse().slice(0, 5);
  res.render('cabinet', {
    title: 'Кабінет — SORACRAFT',
    activeNav: '',
    profile: user,
    history,
    passwordErrors: {}
  });
});

router.post('/cabinet/password', requireAuth, (req, res) => {
  const user = usersModel.findById(req.session.userId);
  const current = req.body.currentPassword || '';
  const next = req.body.newPassword || '';
  const next2 = req.body.newPassword2 || '';

  const passwordErrors = {};
  if (!usersModel.verifyPassword(user, current)) {
    passwordErrors.currentPassword = 'Поточний пароль невірний';
  }
  if (next.length < 8) {
    passwordErrors.newPassword = 'Новий пароль має містити щонайменше 8 символів';
  }
  if (next !== next2 || next2.length === 0) {
    passwordErrors.newPassword2 = 'Паролі не збігаються';
  }

  if (Object.keys(passwordErrors).length > 0) {
    const history = [...(user.loginHistory || [])].reverse().slice(0, 5);
    return res.status(400).render('cabinet', {
      title: 'Кабінет — SORACRAFT',
      activeNav: '',
      profile: user,
      history,
      passwordErrors
    });
  }

  usersModel.updatePassword(user.id, next);
  req.session.flash = { type: 'ok', message: 'Пароль успішно змінено' };
  res.redirect('/cabinet');
});

module.exports = router;
