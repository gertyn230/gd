const express = require('express');
const router = express.Router();
const usersModel = require('../models/users');
const { redirectIfAuthed } = require('../middleware/auth');

router.get('/register', redirectIfAuthed, (req, res) => {
  res.render('register', {
    title: 'Реєстрація — SORACRAFT',
    activeNav: '',
    errors: {},
    values: { nick: '', email: '' }
  });
});

router.post('/register', redirectIfAuthed, (req, res) => {
  const nick = (req.body.nick || '').trim();
  const email = (req.body.email || '').trim();
  const password = req.body.password || '';
  const password2 = req.body.password2 || '';

  const errors = {};
  if (!usersModel.NICK_RE.test(nick)) {
    errors.nick = 'Нікнейм: 3–16 символів, латиниця/цифри/підкреслення';
  } else if (usersModel.findByNick(nick)) {
    errors.nick = 'Цей нікнейм вже зайнятий';
  }
  if (!usersModel.EMAIL_RE.test(email)) {
    errors.email = 'Введи коректну пошту';
  } else if (usersModel.findByEmail(email)) {
    errors.email = 'Акаунт з такою поштою вже існує';
  }
  if (password.length < 8) {
    errors.password = 'Пароль має містити щонайменше 8 символів';
  }
  if (password !== password2 || password2.length === 0) {
    errors.password2 = 'Паролі не збігаються';
  }

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('register', {
      title: 'Реєстрація — SORACRAFT',
      activeNav: '',
      errors,
      values: { nick, email }
    });
  }

  const user = usersModel.create({ nick, email, password });
  req.session.userId = user.id;
  req.session.flash = { type: 'ok', message: 'Акаунт створено! Ласкаво просимо на SORACRAFT.' };
  res.redirect('/cabinet');
});

router.get('/login', redirectIfAuthed, (req, res) => {
  res.render('login', {
    title: 'Вхід — SORACRAFT',
    activeNav: '',
    error: null,
    values: { login: '' }
  });
});

router.post('/login', redirectIfAuthed, (req, res) => {
  const login = (req.body.login || '').trim();
  const password = req.body.password || '';

  if (!login || !password) {
    return res.status(400).render('login', {
      title: 'Вхід — SORACRAFT',
      activeNav: '',
      error: 'Заповни всі поля',
      values: { login }
    });
  }

  const user = usersModel.findByLogin(login);
  if (!user || !usersModel.verifyPassword(user, password)) {
    return res.status(401).render('login', {
      title: 'Вхід — SORACRAFT',
      activeNav: '',
      error: 'Невірний нікнейм/пошта або пароль',
      values: { login }
    });
  }

  if (user.banned) {
    return res.status(403).render('login', {
      title: 'Вхід — SORACRAFT',
      activeNav: '',
      error: 'Цей акаунт заблоковано адміністрацією',
      values: { login }
    });
  }

  usersModel.recordLogin(user.id, req.ip);
  req.session.userId = user.id;
  res.redirect('/cabinet');
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

module.exports = router;
