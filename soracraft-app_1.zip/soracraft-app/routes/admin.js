const express = require('express');
const router = express.Router();
const { requireAuth, requireStaff, requireAdmin } = require('../middleware/auth');
const usersModel = require('../models/users');
const worldsModel = require('../models/worlds');
const newsModel = require('../models/news');

router.use('/admin', requireAuth, requireStaff);

router.get('/admin', (req, res) => {
  const users = usersModel.all();
  res.render('admin/dashboard', {
    title: 'Адмін-панель — SORACRAFT',
    activeNav: '',
    stats: {
      totalUsers: users.length,
      totalAdmins: users.filter((u) => u.role === 'admin').length,
      totalBanned: users.filter((u) => u.banned).length,
      totalWorlds: worldsModel.all().length,
      totalNews: newsModel.all().length
    },
    recentUsers: [...users].reverse().slice(0, 6)
  });
});

router.get('/admin/users', (req, res) => {
  const q = (req.query.q || '').toLowerCase().trim();
  let users = [...usersModel.all()].reverse();
  if (q) {
    users = users.filter(
      (u) => u.nickLower.includes(q) || u.emailLower.includes(q)
    );
  }
  res.render('admin/users', {
    title: 'Керування користувачами — SORACRAFT',
    activeNav: '',
    users,
    query: q
  });
});

// зміна ролі — лише для admin
router.post('/admin/users/:id/role', requireAdmin, (req, res) => {
  const target = usersModel.findById(req.params.id);
  const role = req.body.role;
  const allowed = ['user', 'moderator', 'admin'];

  if (!target) {
    req.session.flash = { type: 'bad', message: 'Користувача не знайдено' };
    return res.redirect('/admin/users');
  }
  if (!allowed.includes(role)) {
    req.session.flash = { type: 'bad', message: 'Невірна роль' };
    return res.redirect('/admin/users');
  }
  if (target.id === req.session.userId && role !== 'admin') {
    req.session.flash = { type: 'bad', message: 'Не можна забрати адмін-права у себе самого' };
    return res.redirect('/admin/users');
  }

  usersModel.setRole(target.id, role);
  req.session.flash = { type: 'ok', message: `Роль користувача ${target.nick} змінено на "${role}"` };
  res.redirect('/admin/users');
});

// бан / розбан — доступно moderator і admin
router.post('/admin/users/:id/ban', (req, res) => {
  const target = usersModel.findById(req.params.id);
  if (!target) {
    req.session.flash = { type: 'bad', message: 'Користувача не знайдено' };
    return res.redirect('/admin/users');
  }
  if (target.id === req.session.userId) {
    req.session.flash = { type: 'bad', message: 'Не можна забанити самого себе' };
    return res.redirect('/admin/users');
  }
  if (target.role === 'admin' && req.session.userRole !== 'admin') {
    req.session.flash = { type: 'bad', message: 'Недостатньо прав' };
    return res.redirect('/admin/users');
  }

  usersModel.setBanned(target.id, !target.banned);
  req.session.flash = {
    type: 'ok',
    message: target.banned
      ? `Користувача ${target.nick} розблоковано`
      : `Користувача ${target.nick} заблоковано`
  };
  res.redirect('/admin/users');
});

// видалення акаунта — лише admin
router.post('/admin/users/:id/delete', requireAdmin, (req, res) => {
  const target = usersModel.findById(req.params.id);
  if (!target) {
    req.session.flash = { type: 'bad', message: 'Користувача не знайдено' };
    return res.redirect('/admin/users');
  }
  if (target.id === req.session.userId) {
    req.session.flash = { type: 'bad', message: 'Не можна видалити самого себе' };
    return res.redirect('/admin/users');
  }
  usersModel.remove(target.id);
  req.session.flash = { type: 'ok', message: `Акаунт ${target.nick} видалено` };
  res.redirect('/admin/users');
});

module.exports = router;
