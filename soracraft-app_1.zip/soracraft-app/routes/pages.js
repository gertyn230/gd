const express = require('express');
const router = express.Router();
const worldsModel = require('../models/worlds');
const newsModel = require('../models/news');

router.get('/', (req, res) => {
  res.render('home', {
    title: 'SORACRAFT — аніме-мережа Minecraft',
    activeNav: 'home',
    worlds: worldsModel.all().slice(0, 3),
    totalOnline: worldsModel.all().reduce((sum, w) => sum + w.online, 0)
  });
});

router.get('/worlds', (req, res) => {
  const worlds = worldsModel.all();
  res.render('worlds', {
    title: 'Світи — SORACRAFT',
    activeNav: 'worlds',
    worlds,
    totalOnline: worlds.reduce((sum, w) => sum + w.online, 0)
  });
});

router.get('/worlds/:slug', (req, res) => {
  const world = worldsModel.findBySlug(req.params.slug);
  if (!world) {
    return res.status(404).render('404', { title: 'Світ не знайдено', activeNav: '' });
  }
  res.render('world-detail', {
    title: world.name + ' — SORACRAFT',
    activeNav: 'worlds',
    world
  });
});

router.get('/launcher', (req, res) => {
  res.render('launcher', {
    title: 'Лаунчер — SORACRAFT',
    activeNav: 'launcher'
  });
});

router.get('/news', (req, res) => {
  res.render('news', {
    title: 'Новини — SORACRAFT',
    activeNav: 'news',
    posts: newsModel.all()
  });
});

router.get('/news/:slug', (req, res) => {
  const post = newsModel.findBySlug(req.params.slug);
  if (!post) {
    return res.status(404).render('404', { title: 'Новину не знайдено', activeNav: '' });
  }
  res.render('news-detail', {
    title: post.title + ' — SORACRAFT',
    activeNav: 'news',
    post
  });
});

module.exports = router;
