document.addEventListener('DOMContentLoaded', function () {

  // copy server IP
  const copyBtn = document.getElementById('copyIpBtn');
  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      const ip = 'play.soracraft.net';
      if (navigator.clipboard) { navigator.clipboard.writeText(ip); }
      const old = copyBtn.textContent;
      copyBtn.textContent = 'Скопійовано!';
      setTimeout(() => (copyBtn.textContent = old), 1500);
    });
  }

  // jittering "live" counters
  function jitterCounter(el, base, spread) {
    const val = base + Math.floor(Math.random() * spread - spread / 2);
    el.textContent = val.toLocaleString('uk-UA');
  }
  const liveOnline = document.getElementById('liveOnline');
  const statPlayers = document.getElementById('statPlayers');
  if (liveOnline || statPlayers) {
    setInterval(() => {
      if (liveOnline) jitterCounter(liveOnline, 1842, 40);
      if (statPlayers) jitterCounter(statPlayers, 1842, 40);
    }, 4000);
  }

  // auto-hide flash message after a few seconds
  const flash = document.querySelector('.form-msg[data-autohide]');
  if (flash) {
    setTimeout(() => { flash.style.transition = 'opacity .4s'; flash.style.opacity = '0'; }, 4000);
  }
});
