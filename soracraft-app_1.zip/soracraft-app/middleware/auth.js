const usersModel = require('../models/users');

// Робить поточного залогіненого користувача доступним у всіх шаблонах як `user`
function attachUser(req, res, next) {
  res.locals.user = null;
  if (req.session && req.session.userId) {
    const user = usersModel.findById(req.session.userId);
    if (user) {
      if (user.banned) {
        // забанений користувач одразу розлогінюється
        return req.session.destroy(() => {
          res.locals.user = null;
          next();
        });
      }
      const { passHash, ...safeUser } = user;
      res.locals.user = safeUser;
    }
  }
  next();
}

// Просте flash-повідомлення через сесію: setFlash -> редірект -> одноразовий показ
function attachFlash(req, res, next) {
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  next();
}

function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    req.session.flash = { type: 'bad', message: 'Спершу увійди в акаунт' };
    return res.redirect('/login');
  }
  next();
}

function redirectIfAuthed(req, res, next) {
  if (req.session && req.session.userId) {
    return res.redirect('/cabinet');
  }
  next();
}

// moderator і admin мають доступ до адмін-панелі (перегляд/бан)
function requireStaff(req, res, next) {
  const user = res.locals.user;
  if (!user || (user.role !== 'admin' && user.role !== 'moderator')) {
    return res.status(403).render('403', { title: 'Доступ заборонено', activeNav: '' });
  }
  next();
}

// лише admin може змінювати ролі та видаляти акаунти
function requireAdmin(req, res, next) {
  const user = res.locals.user;
  if (!user || user.role !== 'admin') {
    return res.status(403).render('403', { title: 'Доступ заборонено', activeNav: '' });
  }
  next();
}

module.exports = {
  attachUser,
  attachFlash,
  requireAuth,
  redirectIfAuthed,
  requireStaff,
  requireAdmin
};
