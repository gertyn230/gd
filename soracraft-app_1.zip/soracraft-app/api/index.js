// Vercel викликає файли з /api як serverless-функції.
// Express app сам по собі є функцією (req, res) => {...}, тому Vercel може
// використати його напряму як handler — без app.listen().
module.exports = require('../app');
